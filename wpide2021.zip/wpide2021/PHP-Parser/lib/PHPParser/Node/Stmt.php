<?php

abstract class PHPParser_Node_Stmt extends PHPParser_NodeAbstract
{
}